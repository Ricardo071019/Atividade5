ID:<?php echo e($autor->ida); ?><br>
Nome:<?php echo e($autor->nome); ?><br>
Nacionalidade:<?php echo e($autor->nacionalidade); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>